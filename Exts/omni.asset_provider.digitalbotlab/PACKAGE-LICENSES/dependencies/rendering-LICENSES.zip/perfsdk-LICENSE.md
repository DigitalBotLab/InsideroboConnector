================================================================================
Apache-2.0
--------------------------------------------------------------------------------

Apache License

Version 2.0, January 2004

http://www.apache.org/licenses/

TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

1. Definitions.

"License" shall mean the terms and conditions for use, reproduction, and distribution as defined by Sections 1 through 9 of this document.

"Licensor" shall mean the copyright owner or entity authorized by the copyright owner that is granting the License.

"Legal Entity" shall mean the union of the acting entity and all other entities that control, are controlled by, or are under common control with that entity. For the purposes of this definition, "control" means (i) the power, direct or indirect, to cause the direction or management of such entity, whether by contract or otherwise, or (ii) ownership of fifty percent (50%) or more of the outstanding shares, or (iii) beneficial ownership of such entity.

"You" (or "Your") shall mean an individual or Legal Entity exercising permissions granted by this License.

"Source" form shall mean the preferred form for making modifications, including but not limited to software source code, documentation source, and configuration files.

"Object" form shall mean any form resulting from mechanical transformation or translation of a Source form, including but not limited to compiled object code, generated documentation, and conversions to other media types.

"Work" shall mean the work of authorship, whether in Source or Object form, made available under the License, as indicated by a copyright notice that is included in or attached to the work (an example is provided in the Appendix below).

"Derivative Works" shall mean any work, whether in Source or Object form, that is based on (or derived from) the Work and for which the editorial revisions, annotations, elaborations, or other modifications represent, as a whole, an original work of authorship. For the purposes of this License, Derivative Works shall not include works that remain separable from, or merely link (or bind by name) to the interfaces of, the Work and Derivative Works thereof.

"Contribution" shall mean any work of authorship, including the original version of the Work and any modifications or additions to that Work or Derivative Works thereof, that is intentionally submitted to Licensor for inclusion in the Work by the copyright owner or by an individual or Legal Entity authorized to submit on behalf of the copyright owner. For the purposes of this definition, "submitted" means any form of electronic, verbal, or written communication sent to the Licensor or its representatives, including but not limited to communication on electronic mailing lists, source code control systems, and issue tracking systems that are managed by, or on behalf of, the Licensor for the purpose of discussing and improving the Work, but excluding communication that is conspicuously marked or otherwise designated in writing by the copyright owner as "Not a Contribution."

"Contributor" shall mean Licensor and any individual or Legal Entity on behalf of whom a Contribution has been received by Licensor and subsequently incorporated within the Work.

2. Grant of Copyright License. Subject to the terms and conditions of this License, each Contributor hereby grants to You a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable copyright license to reproduce, prepare Derivative Works of, publicly display, publicly perform, sublicense, and distribute the Work and such Derivative Works in Source or Object form.

3. Grant of Patent License. Subject to the terms and conditions of this License, each Contributor hereby grants to You a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable (except as stated in this section) patent license to make, have made, use, offer to sell, sell, import, and otherwise transfer the Work, where such license applies only to those patent claims licensable by such Contributor that are necessarily infringed by their Contribution(s) alone or by combination of their Contribution(s) with the Work to which such Contribution(s) was submitted. If You institute patent litigation against any entity (including a cross-claim or counterclaim in a lawsuit) alleging that the Work or a Contribution incorporated within the Work constitutes direct or contributory patent infringement, then any patent licenses granted to You under this License for that Work shall terminate as of the date such litigation is filed.

4. Redistribution. You may reproduce and distribute copies of the Work or Derivative Works thereof in any medium, with or without modifications, and in Source or Object form, provided that You meet the following conditions:

You must give any other recipients of the Work or Derivative Works a copy of this License; and
You must cause any modified files to carry prominent notices stating that You changed the files; and
You must retain, in the Source form of any Derivative Works that You distribute, all copyright, patent, trademark, and attribution notices from the Source form of the Work, excluding those notices that do not pertain to any part of the Derivative Works; and
If the Work includes a "NOTICE" text file as part of its distribution, then any Derivative Works that You distribute must include a readable copy of the attribution notices contained within such NOTICE file, excluding those notices that do not pertain to any part of the Derivative Works, in at least one of the following places: within a NOTICE text file distributed as part of the Derivative Works; within the Source form or documentation, if provided along with the Derivative Works; or, within a display generated by the Derivative Works, if and wherever such third-party notices normally appear. The contents of the NOTICE file are for informational purposes only and do not modify the License. You may add Your own attribution notices within Derivative Works that You distribute, alongside or as an addendum to the NOTICE text from the Work, provided that such additional attribution notices cannot be construed as modifying the License.

You may add Your own copyright statement to Your modifications and may provide additional or different license terms and conditions for use, reproduction, or distribution of Your modifications, or for any such Derivative Works as a whole, provided Your use, reproduction, and distribution of the Work otherwise complies with the conditions stated in this License.
5. Submission of Contributions. Unless You explicitly state otherwise, any Contribution intentionally submitted for inclusion in the Work by You to the Licensor shall be under the terms and conditions of this License, without any additional terms or conditions. Notwithstanding the above, nothing herein shall supersede or modify the terms of any separate license agreement you may have executed with Licensor regarding such Contributions.

6. Trademarks. This License does not grant permission to use the trade names, trademarks, service marks, or product names of the Licensor, except as required for reasonable and customary use in describing the origin of the Work and reproducing the content of the NOTICE file.

7. Disclaimer of Warranty. Unless required by applicable law or agreed to in writing, Licensor provides the Work (and each Contributor provides its Contributions) on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied, including, without limitation, any warranties or conditions of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A PARTICULAR PURPOSE. You are solely responsible for determining the appropriateness of using or redistributing the Work and assume any risks associated with Your exercise of permissions under this License.

8. Limitation of Liability. In no event and under no legal theory, whether in tort (including negligence), contract, or otherwise, unless required by applicable law (such as deliberate and grossly negligent acts) or agreed to in writing, shall any Contributor be liable to You for damages, including any direct, indirect, special, incidental, or consequential damages of any character arising as a result of this License or out of the use or inability to use the Work (including but not limited to damages for loss of goodwill, work stoppage, computer failure or malfunction, or any and all other commercial damages or losses), even if such Contributor has been advised of the possibility of such damages.

9. Accepting Warranty or Additional Liability. While redistributing the Work or Derivative Works thereof, You may choose to offer, and charge a fee for, acceptance of support, warranty, indemnity, or other liability obligations and/or rights consistent with this License. However, in accepting such obligations, You may act only on Your own behalf and on Your sole responsibility, not on behalf of any other Contributor, and only if You agree to indemnify, defend, and hold each Contributor harmless for any liability incurred by, or claims asserted against, such Contributor by reason of your accepting any such warranty or additional liability.

END OF TERMS AND CONDITIONS


================================================================================
NVIDIA NSIGHT PERF SDK LICENSE
--------------------------------------------------------------------------------

This license is a legal agreement between you and NVIDIA Corporation ("NVIDIA")
and governs the use of the NVIDIA Nsight Perf software and materials provided
hereunder (“SDK”). This license can be accepted only by an adult of legal age of
majority in the country in which the SDK is used. If you are entering into this
license on behalf of a company or other legal entity, you represent that you
have the legal authority to bind the entity to this license, in which case “you”
will mean the entity you represent. If you don’t have the required age or
authority to accept this license, or if you don’t accept all the terms and
conditions of this license, do not download, install or use the SDK. You agree
to use the SDK only for purposes that are permitted by (a) this license, and (b)
any applicable law, regulation or generally accepted practices or guidelines in
the relevant jurisdictions.
1. LICENSE. Subject to the terms of this license, NVIDIA hereby grants you a non-exclusive, non-transferable license, without 
the right to sublicense (except as expressly provided in this license) to:
a. Install and use the SDK,
b. Modify and create derivative works of sample or reference source code delivered in the SDK, and
c. Distribute libraries in object code format and headers provided in the SDK, other than versions identified as “Pro”, as 
incorporated into engine and/or tool applications for software development subject to the distribution requirements 
indicated in this license.

2. DISTRIBUTION REQUIREMENTS. These are the distribution requirements for you to exercise the distribution grant above:
a. An application must have material additional functionality, beyond the included portions of the SOFTWARE. 
b. You agree to distribute the SDK subject to the terms at least as protective as the terms of this license, including (without 
limitation) terms relating to the license grant, license restrictions and protection of NVIDIA’s intellectual property rights. 
Additionally, you agree that you will protect the privacy, security and legal rights of your application users. 
c. You agree to notify NVIDIA in writing of any known or suspected distribution or use of the SDK not in compliance with the 
requirements of this license, and to enforce the terms of your agreements with respect to the distributed portions of the 
SDK.

3. AUTHORIZED USERS. You may allow employees and contractors of your entity or of your subsidiary(ies) to access and use 
the SDK from your secure network to perform work on your behalf. If you are an academic institution, you may allow users 
enrolled or employed by the academic institution to access and use the SDK from your secure network. You are responsible 
for the compliance with the terms of this license by your authorized users. 

4. LIMITATIONS. Your license to use the SDK is restricted as follows:
a. The SDK is licensed for you to develop applications only for their use in systems with NVIDIA GPUs.
b. The version of the SDK identified as “Pro” are not distributable under this license.
c. Except as expressly authorized in Section 1c above, the SDK is not licensed for distribution in end user applications. 
Examples of such applications include, but are not limited to, games and CAD/CAM applications.
d. You may not reverse engineer, decompile or disassemble, or remove copyright or other proprietary notices from any 
portion of the SDK or copies of the SDK. 
e. You may not distribute or disclose to third parties the output of the SDK where the output reveals functionality or
performance data pertinent to NVIDIA hardware or software products, results of benchmarking, competitive analysis, 
regression or performance data relating to the SOFTWARE without the prior written permission from NVIDIA. 
f. You may not use the SDK for the purpose of developing competing products or technologies or assisting a third party in 
such activities. 
g. Except as expressly stated above in this license, you may not sell, rent, sublicense, transfer, distribute, modify, or create 
derivative works of any portion of the SDK. 
h. Unless you have an agreement with NVIDIA for this purpose, you may not indicate that an application created with the 
SOFTWARE is sponsored or endorsed by NVIDIA.
i. You may not bypass, disable, or circumvent any technical limitation, encryption, security, digital rights management or 
authentication mechanism in the SDK. 
j. You may not replace any NVIDIA software components in the SDK that are governed by this license with other software
that implements NVIDIA APIs.
k. You may not use the SDK in any manner that would cause it to become subject to an open source software license. As 
examples, licenses that require as a condition of use, modification, and/or distribution that the SDK be: (i) disclosed or 
distributed in source code form; (ii) licensed for the purpose of making derivative works; or (iii) redistributable at no charge.
l. Unless you have an agreement with NVIDIA for this purpose, you may not use the SDK with any system or application 
where the use or failure of the system or application can reasonably be expected to threaten or result in personal injury, 
death, or catastrophic loss. Examples include use in avionics, navigation, military, medical, life support or other life critical 
applications. NVIDIA does not design, test or manufacture the SDK for these critical uses and NVIDIA shall not be liable to you 
or any third party, in whole or in part, for any claims or damages arising from such uses. 
m. You agree to defend, indemnify and hold harmless NVIDIA and its affiliates, and their respective employees, contractors, 
agents, officers and directors, from and against any and all claims, damages, obligations, losses, liabilities, costs or debt, fines, 
restitutions and expenses (including but not limited to attorney’s fees and costs incident to establishing the right of 
indemnification) arising out of or related to your use of the SDK outside of the scope of this license, or not in compliance with 
its terms. 

5. UPDATES. NVIDIA may, at its option, make available patches, workarounds or other updates to this SDK. Unless the updates 
are provided with their separate governing terms, they are deemed part of the SDK licensed to you as provided in this license. 
You agree that the form and content of the SDK that NVIDIA provides may change without prior notice to you. While NVIDIA 
generally maintains compatibility between versions, NVIDIA may in some cases make changes that introduce incompatibilities 
in future versions of the SDK.

6. PRE-RELEASE VERSIONS. SDK versions identified as alpha, beta, preview, early access or otherwise as pre-release may not 
be fully functional, may contain errors or design flaws, and may have reduced or different security, privacy, availability, and 
reliability standards relative to commercial versions of NVIDIA software and materials. You may use a pre-release SDK version 
at your own risk, understanding that these versions are not intended for use in production or business-critical systems. NVIDIA 
may choose not to make available a commercial version of any pre-release SDK. NVIDIA may also choose to abandon 
development and terminate the availability of a pre-release SDK at any time without liability.

7. COMPONENTS UNDER OTHER LICENSES. The SDK may include NVIDIA or third-party components with separate legal 
notices or terms as may be described in proprietary notices accompanying the SDK, such as components governed by open 
source software licenses. If and to the extent there is a conflict between the terms in this license and the license terms 
associated with a component, the license terms associated with the component controls only to the extent necessary to 
resolve the conflict. 

8. OWNERSHIP. 
8.1 NVIDIA reserves all rights, title and interest in and to the SDK not expressly granted to you under this license. NVIDIA and
its suppliers hold all rights, title and interest in and to the SDK, including their respective intellectual property rights. The SDK
is copyrighted and protected by the laws of the United States and other countries, and international treaty provisions.
8.2 Subject to the rights of NVIDIA and its suppliers in the SDK, you hold all rights, title and interest in and to your applications 
and your derivative works of the sample or reference source code delivered in the SDK including their respective intellectual 
property rights. 

9. FEEDBACK. You may, but are not obligated to, provide to NVIDIA Feedback. “Feedback” means suggestions, fixes, 
modifications, feature requests or other feedback regarding the SDK. Feedback, even if designated as confidential by you, 
shall not create any confidentiality obligation for NVIDIA. NVIDIA and its designees have a perpetual, non-exclusive, 
worldwide, irrevocable license to use, reproduce, publicly display, modify, create derivative works of, license, sublicense, and 
otherwise distribute and exploit Feedback as NVIDIA sees fit without payment and without obligation or restriction of any 
kind on account of intellectual property rights or otherwise.

10. NO WARRANTIES. THE SDK IS PROVIDED AS-IS. TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW NVIDIA AND 
ITS AFFILIATES EXPRESSLY DISCLAIM ALL WARRANTIES OF ANY KIND OR NATURE, WHETHER EXPRESS, IMPLIED OR STATUTORY,
INCLUDING, BUT NOT LIMITED TO, WARRANTIES OF MERCHANTABILITY, NON-INFRINGEMENT, OR FITNESS FOR A PARTICULAR 
PURPOSE. NVIDIA DOES NOT WARRANT THAT THE SDK WILL MEET YOUR REQUIREMENTS OR THAT THE OPERATION
THEREOF WILL BE UNINTERRUPTED OR ERROR-FREE, OR THAT ALL ERRORS WILL BE CORRECTED.

11. LIMITATIONS OF LIABILITY. TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW NVIDIA AND ITS AFFILIATES SHALL 
NOT BE LIABLE FOR ANY SPECIAL, INCIDENTAL, PUNITIVE OR CONSEQUENTIAL DAMAGES, OR FOR ANY LOST PROFITS, 
PROJECT DELAYS, LOSS OF USE, LOSS OF DATA OR LOSS OF GOODWILL, OR THE COSTS OF PROCURING SUBSTITUTE 
PRODUCTS, ARISING OUT OF OR IN CONNECTION WITH THIS LICENSE OR THE USE OR PERFORMANCE OF THE SDK, WHETHER 
SUCH LIABILITY ARISES FROM ANY CLAIM BASED UPON BREACH OF CONTRACT, BREACH OF WARRANTY, TORT (INCLUDING 
NEGLIGENCE), PRODUCT LIABILITY OR ANY OTHER CAUSE OF ACTION OR THEORY OF LIABILITY, EVEN IF NVIDIA HAS 
PREVIOUSLY BEEN ADVISED OF, OR COULD REASONABLY HAVE FORESEEN, THE POSSIBILITY OF SUCH DAMAGES. IN NO EVENT 
WILL NVIDIA’S AND ITS AFFILIATES TOTAL CUMULATIVE LIABILITY UNDER OR ARISING OUT OF THIS LICENSE EXCEED US$10.00. 
THE NATURE OF THE LIABILITY OR THE NUMBER OF CLAIMS OR SUITS SHALL NOT ENLARGE OR EXTEND THIS LIMIT. 

12. TERMINATION. Your rights under this license will terminate automatically without notice from NVIDIA if you fail to comply 
with any term and condition of this license or if you commence or participate in any legal proceeding against NVIDIA with 
respect to the SDK. NVIDIA may terminate this license with advance written notice to you, if NVIDIA decides to no longer 
provide the SDK in a country or, in NVIDIA’s sole discretion, the continued use of it is no longer commercially viable. Upon 
any termination of this license, you agree to promptly discontinue use of the SDK and destroy all copies in your possession or 
control. Your prior distributions in accordance with this license are not affected by the termination of this license. All
provisions of this license will survive termination, except for the license granted to you.

13. APPLICABLE LAW. This license will be governed in all respects by the laws of the United States and of the State of Delaware, 
without regard to the conflicts of laws principles. The United Nations Convention on Contracts for the International Sale of 
Goods is specifically disclaimed. You agree to all terms of this license in the English language. The state or federal courts 
residing in Santa Clara County, California shall have exclusive jurisdiction over any dispute or claim arising out of this license. 
Notwithstanding this, you agree that NVIDIA shall still be allowed to apply for injunctive remedies or urgent legal relief in any 
jurisdiction. 

14. NO ASSIGNMENT. This license and your rights and obligations thereunder may not be assigned by you by any means or 
operation of law without NVIDIA’s permission. Any attempted assignment not approved by NVIDIA in writing shall be void 
and of no effect. NVIDIA may assign, delegate or transfer this license and its rights and obligations, and if to a non-affiliate you 
will be notified.

15. EXPORT. The SDK is subject to United States export laws and regulations. You agree to comply with all applicable U.S. and 
international export laws, including the Export Administration Regulations (EAR) administered by the U.S. Department of 
Commerce and economic sanctions administered by the U.S. Department of Treasury’s Office of Foreign Assets Control 
(OFAC). These laws include restrictions on destinations, end-users and end-use. By accepting this license, you confirm that 
you are not currently residing in a country or region currently embargoed by the U.S. and that you are not otherwise 
prohibited from receiving the SDK.

16. GOVERNMENT USE. The SDK is, and shall be treated as being, “Commercial Items” as that term is defined at 48 CFR § 
2.101, consisting of “commercial computer software” and “commercial computer software documentation”, respectively, as 
such terms are used in, respectively, 48 CFR § 12.212 and 48 CFR §§ 227.7202 & 252.227-7014(a)(1). Use, duplication or 
disclosure by the U.S. Government or a U.S. Government subcontractor is subject to the restrictions in this license pursuant 
to 48 CFR § 12.212 or 48 CFR § 227.7202. In no event shall the US Government user acquire rights in the SDK beyond those 
specified in 48 C.F.R. 52.227-19(b)(1)-(2). 

17. NOTICES. Please direct your legal notices or other correspondence to NVIDIA Corporation, 2788 San Tomas Expressway, 
Santa Clara, California 95051, United States of America, Attention: Legal Department.

18. ENTIRE AGREEMENT. This license is the final, complete and exclusive agreement between the parties relating to the 
subject matter of this license and supersedes all prior or contemporaneous understandings and agreements relating to this
subject matter, whether oral or written. If any court of competent jurisdiction determines that any provision of this license is 
illegal, invalid or unenforceable, the remaining provisions will remain in full force and effect. Any amendment or waiver under 
this license shall be in writing and signed by representatives of both parties.
(v. March 29, 2022)



